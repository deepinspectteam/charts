{{/*
Expand the name of the chart.
*/}}
{{- define "deepinspect.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "deepinspect.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Chart label.
*/}}
{{- define "deepinspect.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels applied to every resource.
*/}}
{{- define "deepinspect.labels" -}}
helm.sh/chart: {{ include "deepinspect.chart" . }}
{{ include "deepinspect.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels — used by Deployments and Services.
*/}}
{{- define "deepinspect.selectorLabels" -}}
app.kubernetes.io/name: {{ include "deepinspect.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Service account name.
*/}}
{{- define "deepinspect.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "deepinspect.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Resolve an image reference, optionally prefixing with .Values.imageRegistry.
Note: deliberately read from top-level (NOT .global.imageRegistry) so the
prefix only applies to DeepInspect images, leaving Bitnami subcharts on
docker.io/bitnami.
Usage: {{ include "deepinspect.image" (dict "image" .Values.backend.image "root" .) }}
*/}}
{{- define "deepinspect.image" -}}
{{- $registry := .root.Values.imageRegistry | default "" -}}
{{- $repo := .image.repository -}}
{{- $tag  := .image.tag | default "latest" -}}
{{- if $registry -}}
{{- printf "%s/%s:%s" $registry $repo $tag -}}
{{- else -}}
{{- printf "%s:%s" $repo $tag -}}
{{- end -}}
{{- end }}

{{/*
Auto-populated DATABASE_URL using the in-chart postgres Service.
Format: postgresql://deepinspect:$(POSTGRES_PASSWORD)@<svc>:5432/deepinspect
The password is sourced from deepinspect-db-credentials at runtime.
*/}}
{{- define "deepinspect.databaseUrl" -}}
{{- printf "postgresql://deepinspect:$(POSTGRES_PASSWORD)@%s-postgres:5432/deepinspect" (include "deepinspect.fullname" .) }}
{{- end }}

{{/*
Canonical public gateway domain (the bare host; tenants connect at
<tenant-slug>.<gatewayDomain>). When ingress is enabled, ingress.gatewayHost is
authoritative — it is what the wildcard Ingress rule and TLS cert are built
from, and what the gateway's Lua tenant-slug matcher must agree with. Falls back
to config.gatewayDomain when ingress is disabled (e.g. port-forward/dev).
*/}}
{{- define "deepinspect.gatewayDomain" -}}
{{- if .Values.ingress.enabled -}}
{{- .Values.ingress.gatewayHost -}}
{{- else -}}
{{- .Values.config.gatewayDomain -}}
{{- end -}}
{{- end }}

{{/*
Console origin — the browser-facing URL of the SPA. The frontend calls the API
same-origin (axios baseURL ''), and Better Auth runs at <consoleOrigin>/v1/auth,
so BETTER_AUTH_URL and CORS must match this origin (NOT the api host). Derived
from ingress.frontendHost when ingress is enabled; empty otherwise.
*/}}
{{- define "deepinspect.consoleOrigin" -}}
{{- if .Values.ingress.enabled -}}
{{- printf "https://%s" .Values.ingress.frontendHost -}}
{{- end -}}
{{- end }}

{{/*
Effective BETTER_AUTH_URL: explicit config.betterAuthUrl wins; otherwise derive
from the console origin so browser auth is same-origin by default.
*/}}
{{- define "deepinspect.betterAuthUrl" -}}
{{- .Values.config.betterAuthUrl | default (include "deepinspect.consoleOrigin" .) -}}
{{- end }}

{{/*
Effective CORS_ORIGIN: explicit config.corsOrigin wins; otherwise the console
origin (same-origin, so CORS is a non-issue for the browser).
*/}}
{{- define "deepinspect.corsOrigin" -}}
{{- .Values.config.corsOrigin | default (include "deepinspect.consoleOrigin" .) -}}
{{- end }}

{{/*
Auto-populated REDIS_URL using the in-chart redis Service.
*/}}
{{- define "deepinspect.redisUrl" -}}
{{- printf "redis://%s-redis:6379" (include "deepinspect.fullname" .) }}
{{- end }}

{{/*
Auto-populated S3_ENDPOINT using the in-chart minio Service.
*/}}
{{- define "deepinspect.s3Endpoint" -}}
{{- printf "http://%s-minio:9000" (include "deepinspect.fullname" .) }}
{{- end }}
