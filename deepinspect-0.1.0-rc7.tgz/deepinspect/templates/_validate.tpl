{{/*
Fail-closed TLS guardrail.

Refuses to render templates when ingress is enabled without an explicit
certificate source. Evaluated by tpl invocation in ingress.yaml so the failure
surfaces during `helm install/upgrade` (and `helm template`) with a clear
remediation message.

RFP-defensible: TLS is required by default; explicit customer-controlled
opt-out exists for non-production via ingress.allowInsecure=true.
*/}}
{{- define "deepinspect.validateTLS" -}}
{{- if .Values.ingress.enabled -}}
{{- $hasIssuer := or .Values.certManager.clusterIssuer .Values.certManager.issuer -}}
{{- $hasManualTLS := gt (len .Values.ingress.tls) 0 -}}
{{- $allowInsecure := .Values.ingress.allowInsecure -}}
{{- if and (not $hasIssuer) (not $hasManualTLS) (not $allowInsecure) -}}
{{- $msg := "\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n  DeepInspect refuses to install without TLS configuration.\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n  Configure ONE of the following:\n\n  (1) cert-manager (recommended):\n      --set certManager.clusterIssuer=letsencrypt-prod\n      (Requires cert-manager installed in the cluster with a ClusterIssuer\n      named accordingly. See docs/enterprise-deployment-guide.md.)\n\n  (2) Bring-your-own TLS Secrets:\n      kubectl create secret tls deepinspect-tls --cert=… --key=… -n <ns>\n      --set 'ingress.tls[0].secretName=deepinspect-tls' \\\n      --set 'ingress.tls[0].hosts[0]=api.example.com'\n      (repeat per host)\n\n  (3) DEV/TEST ONLY — proceed without TLS:\n      --set ingress.allowInsecure=true\n      (Cluster will serve plain HTTP. Not for production use.)\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" -}}
{{- fail $msg -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
cert-manager issuer annotation for the WEB ingress (api + console hosts).
Empty when no issuer is set. HTTP-01 is fine for these non-wildcard hosts.
*/}}
{{- define "deepinspect.webCertManagerAnnotation" -}}
{{- if .Values.certManager.clusterIssuer -}}
cert-manager.io/cluster-issuer: {{ .Values.certManager.clusterIssuer | quote }}
{{- else if .Values.certManager.issuer -}}
cert-manager.io/issuer: {{ .Values.certManager.issuer | quote }}
{{- end -}}
{{- end -}}

{{/*
cert-manager issuer annotation for the GATEWAY ingress (wildcard host).
Prefers certManager.gatewayClusterIssuer (expected DNS-01). Falls back to the
web issuer so installs don't break, though an HTTP-01 fallback cannot issue the
wildcard cert. Empty when nothing is set.
*/}}
{{- define "deepinspect.gatewayCertManagerAnnotation" -}}
{{- if .Values.certManager.gatewayClusterIssuer -}}
cert-manager.io/cluster-issuer: {{ .Values.certManager.gatewayClusterIssuer | quote }}
{{- else if .Values.certManager.clusterIssuer -}}
cert-manager.io/cluster-issuer: {{ .Values.certManager.clusterIssuer | quote }}
{{- else if .Values.certManager.issuer -}}
cert-manager.io/issuer: {{ .Values.certManager.issuer | quote }}
{{- end -}}
{{- end -}}

{{/*
TLS block for the WEB ingress (api + console). Manual ingress.tls[] takes
precedence; otherwise auto-generate per-host entries when an issuer is set.
*/}}
{{- define "deepinspect.webIngressTLS" -}}
{{- $hasIssuer := or .Values.certManager.clusterIssuer .Values.certManager.issuer -}}
{{- if gt (len .Values.ingress.tls) 0 -}}
{{- toYaml .Values.ingress.tls -}}
{{- else if $hasIssuer -}}
{{- $name := include "deepinspect.fullname" . -}}
- secretName: {{ $name }}-backend-tls
  hosts:
    - {{ .Values.ingress.backendHost | quote }}
- secretName: {{ $name }}-frontend-tls
  hosts:
    - {{ .Values.ingress.frontendHost | quote }}
{{- end -}}
{{- end -}}

{{/*
TLS block for the GATEWAY ingress (wildcard host). Manual ingress.tls[] takes
precedence (BYO wildcard Secret); otherwise auto-generate a single wildcard
entry when a gateway/cluster issuer is set.
*/}}
{{- define "deepinspect.gatewayIngressTLS" -}}
{{- $hasIssuer := or .Values.certManager.gatewayClusterIssuer (or .Values.certManager.clusterIssuer .Values.certManager.issuer) -}}
{{- if gt (len .Values.ingress.tls) 0 -}}
{{- toYaml .Values.ingress.tls -}}
{{- else if $hasIssuer -}}
{{- $name := include "deepinspect.fullname" . -}}
- secretName: {{ $name }}-gateway-tls
  hosts:
    - {{ printf "*.%s" (include "deepinspect.gatewayDomain" .) | quote }}
{{- end -}}
{{- end -}}
