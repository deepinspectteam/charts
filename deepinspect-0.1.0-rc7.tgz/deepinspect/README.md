# DeepInspect Helm Chart

Umbrella Helm chart that deploys the full DeepInspect stack to Kubernetes, including:

| Component | Type | Description |
|-----------|------|-------------|
| `backend` | Deployment | Fastify API server |
| `payload-worker` | Deployment | Background job processor (same image, custom entrypoint) |
| `frontend` | Deployment | React SPA |
| `gateway` | Deployment | OpenResty/Lua AI proxy |
| `postgresql` | StatefulSet (Bitnami) | Primary database |
| `redis` | StatefulSet (Bitnami) | Cache and compiled policy store |
| `minio` | StatefulSet (Bitnami) | S3-compatible object storage |

A pre-install/pre-upgrade **migration Job** runs `pnpm db:migrate` (and optionally `pnpm db:seed`) automatically on every `helm upgrade --install`.

---

## Prerequisites

- Kubernetes 1.25+
- Helm 3.12+
- `kubectl` configured for your cluster
- AWS CLI (for ECR image pulls — or configure `imagePullSecrets` instead)
- Three Kubernetes Secrets in the target namespace before `helm install` **unless** you use the repo root `deploy.sh`, which creates `deepinspect-db-credentials`, `deepinspect-minio-credentials`, and `deepinspect-app-secrets` idempotently (`--skip-secrets` to opt out).

---

## Step 1 — Create Required Secrets

These secrets must exist before running `helm install` (unless `deploy.sh` created them for you). The chart references them by name but does not create them from Helm templates.

```bash
NAMESPACE=deepinspect
kubectl create namespace $NAMESPACE --dry-run=client -o yaml | kubectl apply -f -

# Database credentials
# Keys: postgres-password (superuser), password (deepinspect app user)
kubectl create secret generic deepinspect-db-credentials \
  --namespace $NAMESPACE \
  --from-literal=postgres-password=<strong-password> \
  --from-literal=password=<strong-password>

# MinIO credentials
# Keys: root-user, root-password
kubectl create secret generic deepinspect-minio-credentials \
  --namespace $NAMESPACE \
  --from-literal=root-user=minio \
  --from-literal=root-password=<strong-password>

# Application secrets
# Required keys: BETTER_AUTH_SECRET, INTERNAL_API_KEY
# Optional keys: STRIPE_SECRET_KEY, RESEND_API_KEY
kubectl create secret generic deepinspect-app-secrets \
  --namespace $NAMESPACE \
  --from-literal=BETTER_AUTH_SECRET=$(openssl rand -hex 32) \
  --from-literal=INTERNAL_API_KEY=$(openssl rand -hex 32) \
  --from-literal=STRIPE_SECRET_KEY=sk_live_... \
  --from-literal=RESEND_API_KEY=re_...
```

> **Using External Secrets Operator?** Sync these secrets from AWS Secrets Manager or Vault instead of creating them manually. The chart only cares that the Secret names and keys match the values in `values.yaml`.

---

## Step 2 — Add Bitnami and Update Dependencies

```bash
helm repo add bitnami https://charts.bitnami.com/bitnami
helm repo update
helm dependency update helm/deepinspect
```

---

## Step 3 — Install

### Minimal install (with bundled PostgreSQL/Redis/MinIO)

```bash
helm upgrade --install deepinspect helm/deepinspect \
  --namespace deepinspect \
  --create-namespace \
  --set config.corsOrigin=https://console.example.com \
  --set config.betterAuthUrl=https://api.example.com \
  --set config.stripePublishableKey=pk_live_... \
  --set ingress.enabled=true \
  --set ingress.backendHost=api.example.com \
  --set ingress.frontendHost=console.example.com \
  --set ingress.gatewayHost=gateway.example.com \
  --atomic \
  --timeout 10m
```

### With a private ECR registry

```bash
helm upgrade --install deepinspect helm/deepinspect \
  --namespace deepinspect \
  --create-namespace \
  --set global.imageRegistry=123456789.dkr.ecr.us-east-1.amazonaws.com \
  --set backend.image.tag=abc1234 \
  --set frontend.image.tag=abc1234 \
  --set gateway.image.tag=abc1234 \
  --set payloadWorker.image.tag=abc1234 \
  --set config.corsOrigin=https://console.example.com \
  --set config.betterAuthUrl=https://api.example.com \
  --set ingress.enabled=true \
  --set ingress.backendHost=api.example.com \
  --set ingress.frontendHost=console.example.com \
  --set ingress.gatewayHost=gateway.example.com \
  --atomic \
  --timeout 10m
```

### Using a values override file (recommended for production)

```bash
helm upgrade --install deepinspect helm/deepinspect \
  --namespace deepinspect \
  --create-namespace \
  -f my-values.yaml \
  --atomic \
  --timeout 10m
```

---

## Key Values Reference

| Value | Default | Description |
|-------|---------|-------------|
| `global.imageRegistry` | `""` | Prefix all image refs (e.g. ECR registry URL) |
| `global.imagePullSecrets` | `[]` | Pull secrets for private registries |
| `backend.replicaCount` | `2` | Backend pod count |
| `backend.image.tag` | `latest` | Backend image tag |
| `frontend.replicaCount` | `2` | Frontend pod count |
| `gateway.replicaCount` | `2` | Gateway pod count |
| `config.nodeEnv` | `production` | `NODE_ENV` |
| `config.corsOrigin` | `https://console.example.com` | Allowed CORS origin for the API |
| `config.betterAuthUrl` | `https://deepinspect.example.com` | Public URL for Better Auth (cookies) |
| `secrets.appSecretName` | `deepinspect-app-secrets` | Secret containing `BETTER_AUTH_SECRET`, `INTERNAL_API_KEY`, etc. |
| `migrationJob.enabled` | `true` | Run DB migrations on install/upgrade |
| `migrationJob.runSeed` | `true` | Also run master data seed |
| `ingress.enabled` | `false` | Enable ingress |
| `ingress.className` | `nginx` | Ingress class |
| `ingress.backendHost` | `api.deepinspect.example.com` | Backend API hostname |
| `ingress.frontendHost` | `console.deepinspect.example.com` | Frontend hostname |
| `ingress.gatewayHost` | `gateway.deepinspect.example.com` | AI gateway hostname |
| `postgresql.enabled` | `true` | Deploy bundled PostgreSQL |
| `redis.enabled` | `true` | Deploy bundled Redis |
| `minio.enabled` | `true` | Deploy bundled MinIO |
| `backend.autoscaling.enabled` | `false` | Enable HPA for backend |

### Inter-service URLs (auto-populated)

`DATABASE_URL`, `REDIS_URL`, and `S3_ENDPOINT` are computed automatically from the Bitnami sub-chart service names using Helm helpers. You do **not** need to set these manually.

If you bring your own PostgreSQL/Redis/MinIO (set `postgresql.enabled: false` etc.), override these in `config` or via environment variables on the deployments.

### Storage classes

Default storage class is `gp3` (AWS EBS). Change per subchart:

```yaml
postgresql:
  primary:
    persistence:
      storageClass: your-class
      size: 20Gi

redis:
  master:
    persistence:
      storageClass: your-class
      size: 8Gi

minio:
  persistence:
    storageClass: your-class
    size: 50Gi
```

---

## Upgrading

```bash
helm dependency update helm/deepinspect   # refresh subchart deps if Chart.yaml changed
helm upgrade deepinspect helm/deepinspect \
  --namespace deepinspect \
  -f my-values.yaml \
  --atomic \
  --timeout 10m
```

The migration Job runs automatically before any pods are replaced. PVCs are retained across upgrades.

---

## Rollback

```bash
# List release history
helm history deepinspect --namespace deepinspect

# Roll back to a previous revision
helm rollback deepinspect <revision> --namespace deepinspect --wait
```

> Note: rolling back does **not** reverse database migrations. If the new schema is not backwards-compatible, restore from a database backup first.

---

## Troubleshooting

### Migration Job failing

```bash
# Check job status
kubectl get jobs -n deepinspect

# View migration logs
kubectl logs -n deepinspect \
  $(kubectl get pods -n deepinspect -l app.kubernetes.io/component=migration \
    -o jsonpath='{.items[0].metadata.name}')
```

Common causes:
- **Secret not found** — check the secret names match `values.yaml` (`secrets.appSecretName`, `deepinspect-db-credentials`, `deepinspect-minio-credentials`)
- **Database not ready** — PostgreSQL StatefulSet may still be initialising on first install; re-run `helm upgrade` once it's healthy
- **Wrong credentials** — verify the `password` key in `deepinspect-db-credentials` matches the PostgreSQL user password

### Pods not starting / ImagePullBackOff

```bash
kubectl describe pod -n deepinspect <pod-name>
```

- Confirm the image tag exists in ECR
- Confirm `global.imageRegistry` matches your ECR registry URL
- If using `imagePullSecrets`, ensure the secret is in the `deepinspect` namespace

### Backend CrashLoopBackOff

```bash
kubectl logs -n deepinspect -l app.kubernetes.io/component=backend --previous
```

- Check `BETTER_AUTH_SECRET` is set in `deepinspect-app-secrets`
- Check `DATABASE_URL` is reachable — confirm PostgreSQL pod is `Running` and `healthy`
- Check `config.betterAuthUrl` matches the actual public URL (wrong value causes auth cookie failures)

### Gateway not enforcing policies

The gateway reads compiled rules from Redis. If Redis is empty or unreachable:

```bash
# Check Redis pod
kubectl get pods -n deepinspect -l app.kubernetes.io/component=redis

# Exec into gateway and test Redis connectivity
kubectl exec -n deepinspect -it \
  $(kubectl get pods -n deepinspect -l app.kubernetes.io/component=gateway \
    -o jsonpath='{.items[0].metadata.name}') -- \
  redis-cli -h $REDIS_HOST ping
```

Rules are compiled by the backend when a forwarding rule is saved. Trigger a recompile by toggling a forwarding rule in the UI.

### Checking all pod status at once

```bash
kubectl get pods -n deepinspect
kubectl get events -n deepinspect --sort-by='.lastTimestamp' | tail -20
```

---

## Architecture

```
                  ┌─────────────────────────────────────────┐
                  │              Ingress (nginx)             │
                  └──────┬──────────────┬───────────────────┘
                         │              │
              ┌──────────┘              └──────────────────┐
              ▼                                            ▼
    ┌──────────────────┐                        ┌─────────────────┐
    │  backend (3000)  │◄──────────────────────►│ gateway (8080)  │
    │  Fastify API     │   internal API key     │ OpenResty/Lua   │
    └──────┬───────────┘                        └────────┬────────┘
           │                                             │
     ┌─────┼───────────────────────────────────┐        │ forwards to
     │     │                                   │        │ upstream AI APIs
     ▼     ▼                                   ▼        ▼
  ┌──────┐ ┌──────────────┐  ┌──────┐   ┌──────────────────────┐
  │  PG  │ │ payload-     │  │Redis │   │      frontend         │
  │  17  │ │ worker       │  │      │   │    React/Vite         │
  └──────┘ └──────────────┘  └──────┘   └──────────────────────┘
              background jobs  policy
                               cache
```
